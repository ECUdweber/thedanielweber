'use strict';

/**
 * @ngdoc function
 * @name applicationToGoApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the applicationToGoApp
 */
angular.module('applicationToGoApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
